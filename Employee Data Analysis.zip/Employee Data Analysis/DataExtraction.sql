--- 28-02-2025 14:58:41 SQLite

Drop TABLE Employee;
CREATE TABLE `Employee` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `EmpId` INT,
    `EmpName` VARCHAR(255),
    `EmpBOD` DATE,
    `EmpJoiningDate` DATE,
    `PrevExperience` INT,
    `Salary` INT,
    `Address` VARCHAR(255)
);
select * from Employee;

INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (1,'Laith Perry','2020-03-29','2019-01-31',2,64072,'990-9029 Duis Street');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (2,'Rudyard Coleman','2019-09-14','2018-10-15',1,98374,'7834 Tempus Road');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (3,'Adam Anthony','2019-06-01','2020-04-11',3,44817,'Ap #608-2097 Ultrices Ave');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (4,'Malcolm Weeks','2019-12-05','2019-07-01',5,13820,'P.O. Box 710, 6880 Lacinia. St.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (5,'Reuben Montgomery','2019-03-22','2019-04-24',1,87591,'P.O. Box 620, 1484 Adipiscing Avenue');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (6,'Porter Wooten','2019-12-19','2020-08-30',5,60392,'543-3259 Ipsum Av.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (7,'Amal Ortiz','2018-12-07','2019-05-05',3,49310,'155 Magna Street');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (8,'Jerome Lewis','2019-05-08','2020-06-20',6,78689,'4654 Vel Avenue');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (9,'Wesley Church','2019-05-24','2019-08-13',9,16118,'P.O. Box 327, 5041 Metus. Rd.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (10,'Ferdinand Nichols','2020-04-21','2020-08-26',4,51307,'Ap #500-5583 Ipsum. Av.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (11,'Chandler Curry','2020-08-16','2018-12-18',2,34767,'3362 Inceptos Road');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (12,'Caleb Patterson','2020-08-03','2020-07-05',3,29678,'7244 Semper Av.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (13,'Bruce Salas','2019-10-17','2020-04-15',1,45594,'P.O. Box 587, 6844 Sem. Av.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (14,'Ferdinand Herman','2019-09-16','2019-03-02',2,66991,'Ap #436-613 Feugiat Ave');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (15,'Judah Graves','2020-02-19','2020-07-09',8,15595,'Ap #765-977 Senectus Ave');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (16,'Stewart Tate','2019-06-02','2019-04-01',8,14861,'P.O. Box 665, 8517 Enim. Rd.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (17,'Vance Kim','2020-03-09','2019-01-06',4,88918,'P.O. Box 286, 6066 Orci Ave');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (18,'Caleb Parrish','2019-04-15','2019-11-06',4,38084,'947-6623 Auctor Rd.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (19,'Jesse Clay','2020-01-16','2020-02-22',2,15332,'4789 Rhoncus. St.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (20,'Lee Leblanc','2019-11-30','2020-04-21',8,68228,'P.O. Box 179, 2688 Aliquam St.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (21,'Xenos Powers','2019-04-02','2020-08-19',6,83031,'Ap #795-9590 Consectetuer St.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (22,'Forrest Wiley','2020-03-06','2020-03-01',1,13814,'P.O. Box 327, 6168 Aliquam Road');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (23,'Burton Leon','2020-07-03','2019-03-16',3,98234,'3167 Rutrum. Rd.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (24,'Benjamin Mcgowan','2020-05-14','2019-05-15',2,24450,'P.O. Box 732, 4057 Malesuada Ave');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (25,'Melvin Cherry','2020-03-24','2019-06-27',4,18501,'Ap #900-8183 Tellus, Rd.');
INSERT INTO `Employee` (`EmpId`,`EmpName`,`EmpBOD`,`EmpJoiningDate`,`PrevExperience`,`Salary`,`Address`) VALUES (26,'Wallace Mcfadden','2019-01-15','2019-09-03',3,99971,'Ap #395-6277 Scelerisque, Ave');

select * from Employee;

-- Add the new column
ALTER TABLE Employee ADD COLUMN ExpLevel VARCHAR(20);

/*select * from Employee;*/
-- Update the ExpLevel based on PrevExperience
UPDATE Employee
SET ExpLevel = CASE
    WHEN PrevExperience >= 1 AND PrevExperience <= 2 THEN 'Intern'
    WHEN PrevExperience >= 3 AND PrevExperience <= 3 THEN 'Junior'
    WHEN PrevExperience = 4 THEN 'Associate'
    WHEN PrevExperience >= 5 AND PrevExperience <= 7 THEN 'Intermediate'
    WHEN PrevExperience >= 8 AND PrevExperience <= 10 THEN 'Senior'
    WHEN PrevExperience > 10 THEN 'Manager'
    ELSE 'Unknown' -- Handle cases outside the defined ranges
END;

select * from Employee;


--Task: Count the total number of employees, and determine the distribution of employees across different experience levels.
--Determine the distribution of employees across each experience level (Intern, Junior, Associate, etc.).

/*select Count(*) as 'Employee number' from Employee;*/

SELECT prevexperience,explevel, Count(*) as 'Employee number'
from Employee 
GROUP by prevexperience;

--Calculate the average, minimum, and maximum salaries for each experience level.

SELECT prevexperience, explevel,avg(salary) as 'Average Salary',
Min(salary) as 'Min Salary',Max(salary) as 'Max salary'
from Employee group by explevel 
order BY prevexperience;

--Calculate the average tenure (in years) of employees within each experience level.

SELECT 
    ExpLevel,
    AVG(CAST(JULIANDAY(DATE('now')) - JULIANDAY(EmpJoiningDate) AS REAL) / 365.25) AS AverageTenureYears
FROM 
    Employee
GROUP BY 
    ExpLevel;
    
--Identify the number of employees hired after 2020-01-01 for each experience level.

SELECT min(empjoiningdate), max(empjoiningdate) from Employee;

SELECT explevel,COUNT(empid) as NewEmployee 
from Employee 
where empjoiningdate >= '2020-01-01' 
GROUP by explevel;

--Identify employees within the "Senior" or "Manager" experience levels who have salaries significantly below the average for their level.
SELECT * from Employee where (SELECT avg(salary) as ExpSalary from Employee where explevel = 'Senior' or explevel = 'manager' ) > salary GROUP by explevel ;

--Determine the most common birthday month for employees within each experience level.
SELECT 
    ExpLevel, 
    BirthMonth, 
    BirthMonthCount
FROM (
    SELECT ExpLevel, 
        strftime('%m', EmpBOD) AS BirthMonth, 
        COUNT(*) AS BirthMonthCount,
        MAX(COUNT(*)) OVER (PARTITION BY ExpLevel) AS MaxCount
    FROM 
        Employee
    GROUP BY 
        ExpLevel, strftime('%m', EmpBOD)
) AS RankedBirthMonths
WHERE 
    BirthMonthCount = MaxCount;

--Analyze if there are any address trends within each experience level.
select empname,explevel,address from Employee where address like 'P.O. Box%' GROUP by explevel;








